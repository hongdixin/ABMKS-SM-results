package scheme.Zhou.ABMKSSM;

import it.unisa.dia.gas.jpbc.Element;

public class ZhoucpabeCphComp {
	/* these actually get serialized */
	String file;
	Element Iwi; /* G_T */
	// Element dp; /* G_1 */

	/* only used during dec */
	// int used;
	/* G_1 */
	// Element zp; /* G_1 */
}
