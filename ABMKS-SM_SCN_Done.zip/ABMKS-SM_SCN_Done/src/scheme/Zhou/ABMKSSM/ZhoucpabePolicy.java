package scheme.Zhou.ABMKSSM;

import java.util.ArrayList;

import it.unisa.dia.gas.jpbc.Element;

public class ZhoucpabePolicy {
	/* serialized */

	/* k=1 if leaf, otherwise threshold */
	int k;
	/* attribute string if leaf, otherwise null */
	String attr;
	Element c; /* G_1 only for leaves */
	Element cp; /* G_1 only for leaves */
	/* array of BswabePolicy and length is 0 for leaves */
	ZhoucpabePolicy[] children;

	/* only used during encryption */
	ZhoucpabePolynomial q;

	/* only used during decrption */
	boolean satisfiable;
	int min_leaves;
	int attri = 3;
	ArrayList<Integer> satl = new ArrayList<Integer>();
}
