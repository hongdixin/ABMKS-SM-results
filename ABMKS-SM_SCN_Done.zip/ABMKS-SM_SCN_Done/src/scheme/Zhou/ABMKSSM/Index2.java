package scheme.Zhou.ABMKSSM;

public class Index2 {
	public String[] word;
	public String[] file;

	public Index2() {

	}

	public Index2(String[] word, String[] file) {
		this.word = word;
		this.file = file;
	}
}
