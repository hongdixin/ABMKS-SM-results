package scheme.Zhou.ABMKSSM;

import java.util.ArrayList;

//import java.util.ArrayList;

import it.unisa.dia.gas.jpbc.Element;

public class ZhoucpabePrv {
	/*
	 * A private key
	 */

	public Element u1, u2, u3; /* Zp */
	public Element g_u1, g_u2, g_u3;/* G1 */
	public Element K1, K2, K3;/* G1 */
	public String identity_id;
	ArrayList<ZhoucpabePrvComp> comps; /* BswabePrvComp */
}