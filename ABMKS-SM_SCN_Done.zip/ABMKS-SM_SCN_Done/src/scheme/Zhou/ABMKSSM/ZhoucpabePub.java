package scheme.Zhou.ABMKSSM;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;

public class ZhoucpabePub {
	/*
	 * A public key
	 */
	public String pairingDesc;
	public Pairing p;
	public Element g; /* G_1 */
	// public Element g_alpha; /* G_1 */
	public Element g_beta; /* G_1 */
	public Element g_hat_alpha; /* G_T */
	// public Element g_alpha;
}
