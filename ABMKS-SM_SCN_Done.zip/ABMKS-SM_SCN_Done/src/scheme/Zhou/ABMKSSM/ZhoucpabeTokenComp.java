package scheme.Zhou.ABMKSSM;

import it.unisa.dia.gas.jpbc.Element;

public class ZhoucpabeTokenComp {
	/* these actually get serialized */
	String attr;
	Element Ta; /* G_1 */
	// Element Bj0; /* G_1 */

	/* only used during dec */
	int used;
	Element z; /* G_1 */
	Element zp; /* G_1 */
}
