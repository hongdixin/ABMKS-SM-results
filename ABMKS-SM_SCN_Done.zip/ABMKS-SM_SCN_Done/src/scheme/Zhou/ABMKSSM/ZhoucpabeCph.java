package scheme.Zhou.ABMKSSM;

import java.util.ArrayList;

import it.unisa.dia.gas.jpbc.Element;

public class ZhoucpabeCph {

	public Element Iw; /* G_1 */
	public Element Ia;
	public ZhoucpabePolicy p;
	ArrayList<ZhoucpabeCphComp> comps_Iwi; /* BswabePrvComp */
	ArrayList<ZhoucpabeCphComp2> comps2_Ia;
}
