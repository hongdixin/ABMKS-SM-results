package scheme.Zhou.ABMKSSM;

import it.unisa.dia.gas.jpbc.Element;

public class ZhoucpabePrvComp {
	/* these actually get serialized */
	String attr;
	Element Ka; /* G_1 */
	// Element dp; /* G_1 */

	/* only used during dec */
	// int used;
	// Element z; /* G_1 */
	// Element zp; /* G_1 */
}
