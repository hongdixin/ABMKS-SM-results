package scheme.Zhou.ABMKSSM;

import it.unisa.dia.gas.jpbc.Element;

public class ZhoucpabeMsk {
	/*
	 * A master secret key
	 */
	public Element alpha, beta; /* Z_r */

}
