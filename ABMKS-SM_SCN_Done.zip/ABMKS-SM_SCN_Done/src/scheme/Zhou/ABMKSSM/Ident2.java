package scheme.Zhou.ABMKSSM;

import java.security.NoSuchAlgorithmException;

public interface Ident2 {
	void T_pairing();

	void setup(ZhoucpabePub pub, ZhoucpabeMsk msk);

	ZhoucpabePrv keygen(ZhoucpabePub pub, ZhoucpabeMsk msk, String identity_id, String[] attrs)
			throws NoSuchAlgorithmException;

	ZhoucpabeCph enc(ZhoucpabePub pub, String[] policy, String[] attrs, String[] word) throws Exception;

	ZhoucpabeToken tokgen(ZhoucpabePrv prv, ZhoucpabePub pub, String[] word) throws Exception;

	boolean search(ZhoucpabePub pub, ZhoucpabeToken token, ZhoucpabeCph cph, String[] attrs) throws Exception;
}
