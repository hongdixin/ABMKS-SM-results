package scheme.Zhou.ABMKSSM;

import java.io.ByteArrayInputStream;

//import it.unisa.dia.gas.jpbc.CurveParameters;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.jpbc.PairingParameters;
//import it.unisa.dia.gas.plaf.jpbc.pairing.DefaultCurveParameters;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;

public class Test_T_MulGT {
	final static String identity_id = "Zhouyunhong";
	private double timeSetup;
	TypeACurveGenerator pg = new TypeACurveGenerator(160, 1024);
	PairingParameters pairingParameters = pg.generate();
	Pairing pairing = PairingFactory.getPairing(pairingParameters);
	Element g0 = pairing.getG1().newRandomElement();
	Element g_hat_alpha = pairing.getGT().newElement();
	Element g_hat_beta = pairing.getGT().newElement();
	public void T_pairing() {
		// g_hat_alpha = pairing.pairing(g0, g0);
		for (int j = 0; j < 500000; j++) {
			g_hat_alpha.mul(g_hat_beta);
			// pairing.pairing(g0, g0);
		}

		// g_hat_alpha.powZn(alpha);

	}

	public static void main(String[] args) throws Exception {
		Test_T_MulGT test = new Test_T_MulGT();
		// double sum0 = 0;
		Timer timer = new Timer();
		int round = 1000;
		double temperTime;
		for (int j = 0; j < round; j++) {
			System.out.println("��������ʱ�䣻 ");
			timer.start(0);
			test.T_pairing();
			temperTime = timer.stop(0);
			System.out.println(temperTime);
			test.timeSetup += temperTime;
			// sum0+=test.timeSetup;

		}

		System.out.println(test.timeSetup / round);
	}

}
