package scheme.Zhou.ABMKSSM;

//import it.unisa.dia.gas.jpbc.CurveParameters;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.jpbc.PairingParameters;
//import it.unisa.dia.gas.plaf.jpbc.pairing.DefaultCurveParameters;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;

import java.io.ByteArrayInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

//import index.Index;

public class Zhoucpabe {
	final static boolean DEBUG = true;
	private double timeSetup;
	private double KeyGen;
	private double enc;
	private double token;
	private double Search;
	
	// ���ʲ��Ժ����Ե���������10
	static String[] attrs = { "baf", "fim1", "fim", "foo", "fim2", "foo1", "baf1", "fim3", "foo2", "baf2" };
	static String[] policy = { "baf", "fim1", "fim", "foo", "fim2", "foo1", "baf1", "fim3", "foo2", "baf2" };

// ���ʲ��Ժ����Ե���������20
//static String[] attrs = { "baf", "fim1", "fim", "foo", "fim2", "foo1", "baf1", "fim3", "foo2", "baf2", "baf4",
//"fim4", "foo4", "baf5", "fim5", "foo5", "baf7", "fim7", "foo7", "baf8" };
//static String[] policy = { "baf", "fim1", "fim", "foo", "fim2", "foo1", "baf1", "fim3", "foo2", "baf2", "baf4",
//"fim4", "foo4", "baf5", "fim5", "foo5", "baf7", "fim7", "foo7", "baf8" };
//���ʲ��Ժ����Ե���������40
//static String[] attrs = { "baf", "fim1", "fim","foo","fim2","foo1","baf1","fim3","foo2","baf2","baf4","fim4","foo4","baf5","fim5","foo5","baf7","fim7","foo7","baf8","baf40", "fim140", "fim40","foo40","fim240","foo140","baf140","fim340","foo240","baf240","baf440","fim440","foo440","baf540","fim540","foo540","baf740","fim740","foo740","baf840"};
//static String[] policy = { "baf", "fim1", "fim","foo","fim2","foo1","baf1","fim3","foo2","baf2","baf4","fim4","foo4","baf5","fim5","foo5","baf7","fim7","foo7","baf8","baf40", "fim140", "fim40","foo40","fim240","foo140","baf140","fim340","foo240","baf240","baf440","fim440","foo440","baf540","fim540","foo540","baf740","fim740","foo740","baf840"};
//���ʲ��Ժ����Ե���������60
//static String[] attrs = { "baf", "fim1", "fim","foo","fim2","foo1","baf1","fim3","foo2","baf2","baf4","fim4","foo4","baf5","fim5","foo5","baf7","fim7","foo7","baf8","baf40", "fim140", "fim40","foo40","fim240","foo140","baf140","fim340","foo240","baf240","baf440","fim440","foo440","baf540","fim540","foo540","baf740","fim740","foo740","baf840", "baf60", "fim160", "fim60","foo60","fim260","foo160","baf160","fim360","foo260","baf260","baf460","fim460","foo460","baf560","fim560","foo560","baf760","fim760","foo760","baf860"};
//static String[] policy = { "baf", "fim1", "fim","foo","fim2","foo1","baf1","fim3","foo2","baf2","baf4","fim4","foo4","baf5","fim5","foo5","baf7","fim7","foo7","baf8","baf40", "fim140", "fim40","foo40","fim240","foo140","baf140","fim340","foo240","baf240","baf440","fim440","foo440","baf540","fim540","foo540","baf740","fim740","foo740","baf840", "baf60", "fim160", "fim60","foo60","fim260","foo160","baf160","fim360","foo260","baf260","baf460","fim460","foo460","baf560","fim560","foo560","baf760","fim760","foo760","baf860"};
//���ʲ��Ժ����Ե���������80
//static String[] attrs = { "baf", "fim1", "fim","foo","fim2","foo1","baf1","fim3","foo2","baf2","baf4","fim4","foo4","baf5","fim5","foo5","baf7","fim7","foo7","baf8","baf40", "fim140", "fim40","foo40","fim240","foo140","baf140","fim340","foo240","baf240","baf440","fim440","foo440","baf540","fim540","foo540","baf740","fim740","foo740","baf840", "baf60", "fim160", "fim60","foo60","fim260","foo160","baf160","fim360","foo260","baf260","baf460","fim460","foo460","baf560","fim560","foo560","baf760","fim760","foo760","baf860","baf80", "fim180", "fim80","foo80","fim280","foo180","baf180","fim380","foo280","baf280","baf480","fim480","foo480","baf580","fim580","foo580","baf780","fim780","foo780","baf880"};
//static String[] policy = { "baf", "fim1", "fim","foo","fim2","foo1","baf1","fim3","foo2","baf2","baf4","fim4","foo4","baf5","fim5","foo5","baf7","fim7","foo7","baf8","baf40", "fim140", "fim40","foo40","fim240","foo140","baf140","fim340","foo240","baf240","baf440","fim440","foo440","baf540","fim540","foo540","baf740","fim740","foo740","baf840", "baf60", "fim160", "fim60","foo60","fim260","foo160","baf160","fim360","foo260","baf260","baf460","fim460","foo460","baf560","fim560","foo560","baf760","fim760","foo760","baf860","baf80", "fim180", "fim80","foo80","fim280","foo180","baf180","fim380","foo280","baf280","baf480","fim480","foo480","baf580","fim580","foo580","baf780","fim780","foo780","baf880"};
//���ʲ��Ժ����Ե���������100

	/*
	 * static String[] attrs = { "baf", "fim1", "fim", "foo", "fim2", "foo1",
	 * "baf1", "fim3", "foo2", "baf2", "baf4", "fim4", "foo4", "baf5", "fim5",
	 * "foo5", "baf7", "fim7", "foo7", "baf8", "baf40", "fim140", "fim40", "foo40",
	 * "fim240", "foo140", "baf140", "fim340", "foo240", "baf240", "baf440",
	 * "fim440", "foo440", "baf540", "fim540", "foo540", "baf740", "fim740",
	 * "foo740", "baf840", "baf60", "fim160", "fim60", "foo60", "fim260", "foo160",
	 * "baf160", "fim360", "foo260", "baf260", "baf460", "fim460", "foo460",
	 * "baf560", "fim560", "foo560", "baf760", "fim760", "foo760", "baf860",
	 * "baf80", "fim180", "fim80", "foo80", "fim280", "foo180", "baf180", "fim380",
	 * "foo280", "baf280", "baf480", "fim480", "foo480", "baf580", "fim580",
	 * "foo580", "baf780", "fim780", "foo780", "baf880", "baf100", "fim1100",
	 * "fim100", "foo100", "fim2100", "foo1100", "baf1100", "fim3100", "foo2100",
	 * "baf2100", "baf4100", "fim4100", "foo4100", "baf5100", "fim5100", "foo5100",
	 * "baf7100", "fim7100", "foo7100", "baf8100" }; static String[] policy = {
	 * "baf", "fim1", "fim", "foo", "fim2", "foo1", "baf1", "fim3", "foo2", "baf2",
	 * "baf4", "fim4", "foo4", "baf5", "fim5", "foo5", "baf7", "fim7", "foo7",
	 * "baf8", "baf40", "fim140", "fim40", "foo40", "fim240", "foo140", "baf140",
	 * "fim340", "foo240", "baf240", "baf440", "fim440", "foo440", "baf540",
	 * "fim540", "foo540", "baf740", "fim740", "foo740", "baf840", "baf60",
	 * "fim160", "fim60", "foo60", "fim260", "foo160", "baf160", "fim360", "foo260",
	 * "baf260", "baf460", "fim460", "foo460", "baf560", "fim560", "foo560",
	 * "baf760", "fim760", "foo760", "baf860", "baf80", "fim180", "fim80", "foo80",
	 * "fim280", "foo180", "baf180", "fim380", "foo280", "baf280", "baf480",
	 * "fim480", "foo480", "baf580", "fim580", "foo580", "baf780", "fim780",
	 * "foo780", "baf880", "baf100", "fim1100", "fim100", "foo100", "fim2100",
	 * "foo1100", "baf1100", "fim3100", "foo2100", "baf2100", "baf4100", "fim4100",
	 * "foo4100", "baf5100", "fim5100", "foo5100", "baf7100", "fim7100", "foo7100",
	 * "baf8100" };
	 */

//�ؼ���������10	
//final static String[] word = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
//�ؼ���������20	
final static String[] word = {  "1", "2", "3", "4", "5", "6", "7", "8", "9","10","11", "12", "13", "14", "15", "16", "17", "18", "19","20"};
//�ؼ���������40	
	// final static String[] word = { "1", "2", "3", "4", "5", "6", "7", "8",
	// "9","10","11", "12", "13", "14", "15", "16", "17", "18", "19","20","21",
	// "22", "23", "24", "25", "26", "27", "28", "29","30","31", "32", "33", "34",
	// "35", "36", "37", "38", "39","40"};
//�ؼ���������60	
//final static String[] word = {  "1", "2", "3", "4", "5", "6", "7", "8", "9","10","11", "12", "13", "14", "15", "16", "17", "18", "19","20","21", "22", "23", "24", "25", "26", "27", "28", "29","30","31", "32", "33", "34", "35", "36", "37", "38", "39","40","41", "42", "43", "44", "45", "46", "47", "48", "49","50","51", "52", "53", "54", "55", "56", "57", "58", "59","60"};
//�ؼ���������80	
//final static String[] word = {  "1", "2", "3", "4", "5", "6", "7", "8", "9","10","11", "12", "13", "14", "15", "16", "17", "18", "19","20","21", "22", "23", "24", "25", "26", "27", "28", "29","30","31", "32", "33", "34", "35", "36", "37", "38", "39","40","41", "42", "43", "44", "45", "46", "47", "48", "49","50","51", "52", "53", "54", "55", "56", "57", "58", "59","60","61", "62", "63", "64", "65", "66", "67", "68", "69","70","71", "72", "73", "74", "75", "76", "77", "78", "79","80"};
//�ؼ���������100
	/*
	 * final static String[] word = { "1", "2", "3", "4", "5", "6", "7", "8", "9",
	 * "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22",
	 * "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35",
	 * "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48",
	 * "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61",
	 * "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74",
	 * "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87",
	 * "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100"
	 * };
	 */
	final static String identity_id = "Zhouyunhong";
	
	TypeACurveGenerator pg = new TypeACurveGenerator(160, 1024);
	PairingParameters pairingParameters = pg.generate();
	Pairing pairing = PairingFactory.getPairing(pairingParameters);

	public void setup(ZhoucpabePub pub, ZhoucpabeMsk msk) {
		System.out.println("---setup phase---");
		
		msk.alpha = pairing.getZr().newRandomElement();
		msk.beta = pairing.getZr().newRandomElement();
		pub.g = pairing.getG1().newRandomElement();
		pub.g_beta = pairing.getG1().newElement();
		pub.g_hat_alpha = pairing.getGT().newElement();

		pub.g_beta = pub.g.duplicate();
		pub.g_beta = pub.g_beta.powZn(msk.beta);
		
		pub.g_hat_alpha = pairing.pairing(pub.g, pub.g).duplicate();
		
		pub.g_hat_alpha.powZn(msk.alpha);

	}


	public ZhoucpabePrv keygen(ZhoucpabePub pub, ZhoucpabeMsk msk, String identity_id, String[] attrs)
			throws NoSuchAlgorithmException {
		System.out.println("---begin key generation phase---");
		ZhoucpabePrv prv = new ZhoucpabePrv();
		Element r;
		// Pairing pairing = pub.p;
		prv.u1 = pairing.getZr().newRandomElement();
		prv.u2 = pairing.getZr().newRandomElement();
		prv.u3 = pairing.getZr().newRandomElement();
		prv.g_u1 = pairing.getG1().newElement();
		prv.g_u2 = pairing.getG1().newElement();
		prv.g_u3 = pairing.getG1().newElement();

		prv.g_u1 = pub.g.duplicate();
		prv.g_u1.powZn(prv.u1);
		prv.g_u2 = pub.g.duplicate();
		prv.g_u2.powZn(prv.u2);
		prv.g_u3 = pub.g.duplicate();
		prv.g_u3.powZn(prv.u3);

		prv.K1 = pairing.getG1().newElement();

		r = pairing.getZr().newRandomElement();

		prv.K1 = pub.g.duplicate();
		prv.K1.powZn(r);

		prv.K2 = pairing.getG1().newElement();
		prv.K2 = pub.g.duplicate();
		prv.K2.powZn(msk.alpha);
		prv.K3 = pairing.getG1().newElement();
		prv.K3 = prv.K2.duplicate();
		Element ID = pairing.getG1().newElement();
		elementFromString(ID, identity_id);
		ID.powZn(msk.beta);
		prv.K3.mul(ID);

		int i, len = attrs.length;
		prv.comps = new ArrayList<ZhoucpabePrvComp>();
		for (i = 0; i < len; i++) {
			ZhoucpabePrvComp comp = new ZhoucpabePrvComp();
			comp.attr = attrs[i];
			Element h = pairing.getZr().newElement();
			byte[] h_rp = comp.attr.getBytes();
			h = h.setFromHash(h_rp, 0, h_rp.length); 
			comp.Ka = pairing.getG1().newElement();
			
			comp.Ka = pub.g.duplicate();
			comp.Ka.powZn(h);
			comp.Ka.mul(prv.K1);
			prv.comps.add(comp);
		}

		return prv;

	}

	private static void elementFromString(Element h, String s) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("SHA-1");
		byte[] digest = md.digest(s.getBytes());
		h.setFromHash(digest, 0, digest.length);
	}

	public ZhoucpabeCph enc(ZhoucpabePub pub, String[] policy, String[] attrs, String[] word) // ����ֻ��ע�������ɹ��̡�
			throws Exception {
		System.out.println("---begin enc phase---");
		ZhoucpabeCph cph = new ZhoucpabeCph();
		
		Element theta;

		cph.Iw = pairing.getG1().newElement();
		theta = pairing.getZr().newRandomElement();

		cph.Iw = pub.g.duplicate();
		cph.Iw.powZn(theta);

	

		Element W01 = pairing.getGT().newElement();
		W01 = pub.g_hat_alpha.duplicate();
		W01.powZn(theta);

		
		int i;
		cph.comps_Iwi = new ArrayList<ZhoucpabeCphComp>();

		
		for (i = 0; i < word.length; i++) {
			ZhoucpabeCphComp comp = new ZhoucpabeCphComp();
			comp.file = word[i];
			Element m = pairing.getG1().newElement();
			elementFromString(m, word[i]);
			
			comp.Iwi = pairing.getGT().newElement();
			comp.Iwi = pairing.pairing(cph.Iw, m);
			comp.Iwi.mul(W01); 
			cph.comps_Iwi.add(comp);
			
		}
		
		if (isContain(policy, attrs)) {

			int j;
			cph.comps2_Ia = new ArrayList<ZhoucpabeCphComp2>();

			for (j = 0; j < policy.length; j++) {
				ZhoucpabeCphComp2 comp2 = new ZhoucpabeCphComp2();
				comp2.attr = policy[j];
				Element h1 = pairing.getZr().newElement();
				byte[] ind = comp2.attr.getBytes();
				h1 = h1.setFromHash(ind, 0, ind.length);
				comp2.Ia = pairing.getG1().newElement();
				comp2.Ia = cph.Iw.duplicate();

				comp2.Ia.powZn(h1);
				cph.comps2_Ia.add(comp2);
				
			}

		}

		else {
			System.out.print("error");

		}

		return cph;
	}

	public static boolean isContain(String[] policy, String[] attrs) {
		boolean ret = false;
		for (int i = 0; i < attrs.length; i++) {
			if (policy[i].equals(attrs[i])) {
				ret = true;

			}
		}

		return ret;
	}

	public ZhoucpabeToken tokgen(ZhoucpabePrv prv, ZhoucpabePub pub, String[] word) throws Exception {

		System.out.println("---begin token generation phase---");
		
		ZhoucpabeToken token = new ZhoucpabeToken();
		token.tok = pairing.getG1().newElement();
	
		token.tok = prv.K1.duplicate();

		Element k2 = pairing.getG1().newElement();
		k2 = prv.K2.duplicate();
		for (int i = 0; i < word.length; i++) {
			token.tok.mul(k2);
			
		}
		
		Element WD = pairing.getG1().newElement();
		for (int i = 0; i < word.length; i++) {
			
			elementFromString(WD, word[i]);
			token.tok.mul(WD);
		
		}
	

		token.comps = new ArrayList<ZhoucpabeTokenComp>();

		for (int i = 0; i < prv.comps.size(); i++) {
			
			ZhoucpabeTokenComp comp_token = new ZhoucpabeTokenComp();
			comp_token.attr = attrs[i];
		
			comp_token.Ta = prv.comps.get(i).Ka.getImmutable().duplicate();

			token.comps.add(comp_token);
			
		}
	return token;

	}

	public boolean search(ZhoucpabePub pub, ZhoucpabeToken token, ZhoucpabeCph cph, String[] attrs) throws Exception {

		System.out.println("---begin search generation phase---");

		boolean ret = false;
		
		if (!isContain(policy, attrs)) { // ������ʲ���
			System.err.println("cannot search, attributes in cph do not satisfy policy");
			ret = false;
			return ret;
		}
		
		Element left = pairing.getGT().newElement();
		left.setToOne();

		for (int i = 0; i < word.length; i++) {

			left.mul(cph.comps_Iwi.get(i).Iwi);

		}
		

		Element right = pairing.getGT().newElement();
		
		right = pairing.pairing(cph.Iw, token.tok).duplicate();
		
		left.mul(pairing.pairing(cph.Iw, token.comps.get(0).Ta));
		right.mul(pairing.pairing(pub.g, cph.comps2_Ia.get(0).Ia));
		
		if (left.equals(right)) {
			ret = true;
			System.out.println("�����ɹ�");
		} else {
			System.out.println("����ʧ��");
		}

		return ret;
	}

	
	public static void main(String[] args) throws Exception {
		System.out.println("ABMKS-SM Construction implements:");
		ZhoucpabePub pub = new ZhoucpabePub();
		ZhoucpabeMsk msk = new ZhoucpabeMsk();
		ZhoucpabePrv prv;
		ZhoucpabeToken token;
		ZhoucpabeCph cph;
		boolean result = false;
		Zhoucpabe ident = new Zhoucpabe();
		
		int round = 50;
		double temperTime;
		Timer timer = new Timer();

		for (int j = 0; j < round; j++) {
			System.out.println("���ǵ�Setup����ʱ�䣻 ");
			timer.start(0);
			ident.setup(pub, msk);
			temperTime = timer.stop(0);
			ident.timeSetup += temperTime;
			System.out.println(temperTime);
			
			System.out.println("���ǵ�keygen����ʱ�䣻 ");
			timer.start(0);
			prv = ident.keygen(pub, msk, identity_id, attrs);
			temperTime = timer.stop(0);
			ident.KeyGen += temperTime;
			System.out.println(temperTime);
			

			System.out.println("���ǵ�enc����ʱ�䣻 ");
			timer.start(0);
			cph = ident.enc(pub, policy, attrs, word);
			temperTime = timer.stop(0);
			ident.enc += temperTime;
	
			System.out.println(temperTime);
			System.out.println("���ǵ�tokgen����ʱ�䣻 ");
			timer.start(0);
			token = ident.tokgen(prv, pub, word);
			temperTime = timer.stop(0);
			ident.token += temperTime;
			System.out.println(temperTime);
		
			System.out.println("���ǵ�search����ʱ�䣻 ");
			timer.start(0);
			result = ident.search(pub, token, cph, attrs);
			temperTime = timer.stop(0);
			ident.Search += temperTime;
			System.out.println(temperTime);
		
		}
		System.out.println(ident.timeSetup / round);
		System.out.println(ident.KeyGen / round);
		System.out.println(ident.enc / round);
		System.out.println(ident.token / round);
		System.out.println(ident.Search / round);

	}
}
