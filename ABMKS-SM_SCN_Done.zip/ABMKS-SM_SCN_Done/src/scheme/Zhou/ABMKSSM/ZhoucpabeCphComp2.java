package scheme.Zhou.ABMKSSM;

import it.unisa.dia.gas.jpbc.Element;

public class ZhoucpabeCphComp2 {
	/* these actually get serialized */
	/* G_T */
	// Element dp; /* G_1 */

	/* only used during dec */
	// int used;
	String attr;
	Element Ia; /* G_1 */
	// Element zp; /* G_1 */
}
