package scheme.Zhou.ABMKSSM;

import java.util.ArrayList;

import it.unisa.dia.gas.jpbc.Element;

public class ZhoucpabeToken {
	public Element tok; /* G_1 */
	ArrayList<ZhoucpabeTokenComp> comps;
}
